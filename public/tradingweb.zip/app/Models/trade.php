<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class trade extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'market',
        'trx',
        'package_id',
        'amount',
        'rate_stake',
        'rate_end',
        'status',
        'win_lost'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function package()
    {
        return $this->belongsTo(package::class, 'package_id', 'id');
    }
}
