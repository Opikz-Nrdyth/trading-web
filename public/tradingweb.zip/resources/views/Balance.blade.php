@extends('layouts.app')
@section('title', 'Referals')
@section('route', end($route))

@section('content')
    <x-breadcrumb :route="$route" title="{{ $title }}" />
    <livewire:tabel title='Virtual Balance [SGD {{ $totalBalance }}]' action="{{ true }}"
        searchbar="{{ true }}" :header="$header" :colum="$colum" :searchableHeaders="$filtered" />
@endsection
